Application Helm chart skeleton.
